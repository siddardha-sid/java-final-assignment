package ineuron.controller;

import java.io.Serializable;
import java.util.List;
import java.util.Scanner;


import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import ineuron.model.Employee;
import ineuron.util.Util;

public class Test {
	static Session session=null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	fetchAll().stream().forEach(e->System.out.println("employee details"+e));
	}
	
	
public static List<Employee> fetchAll(){
	session=Util.getSession();
    Query query = session.createQuery("FROM Employee");
    List<Employee> emp = query.list();
    return emp;
}

}
