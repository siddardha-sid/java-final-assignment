package ineuron.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import ineuron.model.Employee;

public class Util {
private Util() {
	
}
static Configuration config=null;
static SessionFactory sessionfactory=null;
static Session session=null;
public static Session getSession() {
	config=new Configuration();
	config.configure().addAnnotatedClass(Employee.class);
	if(config!=null) {
		sessionfactory=config.buildSessionFactory();
		session=sessionfactory.openSession();
	}
	return session;
}
}
