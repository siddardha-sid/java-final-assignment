package ineuron.controller;

import java.io.Serializable;
import java.util.List;
import java.util.Scanner;


import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import ineuron.model.Employee;
import ineuron.util.Util;

public class Test {
	static Session session=null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
try {
	Scanner scan=new Scanner(System.in);
	System.out.println("please enter name:");
	String name=scan.next();
	System.out.println("please enter college:");
	String college=scan.next();
	 session=Util.getSession();
	Employee emp=new Employee();
	emp.setName(name);
	emp.setCollege(college);
	Integer id=(Integer) session.save(emp);
	System.out.println(id);
	
	fetchAll().stream().forEach(e->System.out.println(e));
	
}catch(Exception e) {
	e.printStackTrace();
	
}finally {
	session.close();
}
	}
	
	
public static List<Employee> fetchAll(){
	session=Util.getSession();
    Query query = session.createQuery("FROM Employee");
    List<Employee> emp = query.list();
    return emp;
}

}
