package ineuron.controller;

import java.io.Serializable;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import ineuron.model.Employee;
import ineuron.util.Util;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session=null;
		Transaction transaction=null;
		session=Util.getSession();
		
try {
	Employee emp=session.get(Employee.class,2);
	System.out.println("before updating "+emp.getClient_salary());
	if(emp!=null) {
		transaction=session.beginTransaction();
		emp.setClient_salary(75000);
		session.update(emp);
		transaction.commit();
		System.out.println("After updating "+emp.getClient_salary());
	}
	
}catch(Exception e) {
	e.printStackTrace();
	
}finally {
	session.close();
}
	}

}
