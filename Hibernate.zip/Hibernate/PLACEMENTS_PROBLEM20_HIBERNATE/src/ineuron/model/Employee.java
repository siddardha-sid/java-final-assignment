package ineuron.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="CLIENTS")
public class Employee implements Serializable {
	private static final long serialVersionUID = 1L;
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Integer client_id;
private String client_name;
private String address;
private Integer client_salary;
public Integer getClient_id() {
	return client_id;
}
public void setClient_id(Integer client_id) {
	this.client_id = client_id;
}
public String getClient_name() {
	return client_name;
}
public void setClient_name(String client_name) {
	this.client_name = client_name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public Integer getClient_salary() {
	return client_salary;
}
public void setClient_salary(Integer client_salary) {
	this.client_salary = client_salary;
}
public static long getSerialversionuid() {
	return serialVersionUID;
}
@Override
public String toString() {
	return "Employee [client_id=" + client_id + ", client_name=" + client_name + ", address=" + address
			+ ", client_salary=" + client_salary + "]";
}


}
