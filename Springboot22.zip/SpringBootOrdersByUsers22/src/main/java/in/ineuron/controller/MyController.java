package in.ineuron.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import in.ineuron.model.Orders;
import in.ineuron.service.IEmployeeService;
import in.ineuron.service.StudentServiceImpl;

@RestController
public class MyController {

	@Autowired
	private IEmployeeService empservice;
	
	@GetMapping("api/find/{id}")
	public ResponseEntity<Orders> serviceProvider( @PathVariable("id") Integer userid) {
		List<Orders> orders= empservice.getData(userid);
		orders.forEach(e->System.out.println(e.getUser()));
		return new ResponseEntity<Orders>((Orders) orders,HttpStatus.OK );
	}
	
	
}
