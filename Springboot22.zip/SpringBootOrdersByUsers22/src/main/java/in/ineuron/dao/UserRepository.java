package in.ineuron.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import in.ineuron.model.Orders;

public interface UserRepository  extends JpaRepository<Orders, Integer>{
 public List<Orders> findByUserId(Integer e);
}
