package in.ineuron.service;

import java.util.List;

import in.ineuron.model.Orders;

public interface IEmployeeService {

	public List<Orders> getData(Integer e);
}
