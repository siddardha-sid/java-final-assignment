package in.ineuron.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.dao.UserRepository;
import in.ineuron.model.Orders;


@Service
public class StudentServiceImpl implements IEmployeeService {
    @Autowired
	private UserRepository repo;
	
	@Override
	public List<Orders> getData(Integer e) {
		List<Orders> li=repo.findByUserId(e);
		return li;
	}

}
