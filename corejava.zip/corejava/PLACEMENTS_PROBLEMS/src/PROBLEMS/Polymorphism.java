package PROBLEMS;
interface Shape{
	public double perimeter();
	public double area();
}
class Circle implements Shape{

	private double radius;

    public Circle(double radius) {
        this.radius=radius;
    }
	
	@Override
	public double perimeter() {
		return Math.PI*radius*radius;
	}

	@Override
	public double area() {
		return 2*Math.PI*radius;
	}
	
}
class Triangle implements Shape{

	 private double base;
	    private double height;
	    private double side1;
	    private double side2;
	    private double side3;

	    public Triangle(double base, double height, double side1, double side2, double side3) {
	        this.base = base;
	        this.height = height;
	        this.side1 = side1;
	        this.side2 = side2;
	        this.side3 = side3;
	    }
	@Override
	public double perimeter() {
		return side1 + side2 + side3;
	}

	@Override
	public double area() {
		return 0.5 * base * height;
	}
	
}
public class Polymorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape circle=new Circle(10);
		System.out.println("area of circle "+circle.area());
		System.out.println("circle perimeter"+circle.perimeter());
		
		System.out.println();
		
		 Shape triangle = new Triangle(4,3,5,4,3);
	     System.out.println("triangle Area: " + triangle.area());
	     System.out.println("triangle Perimeter: " + triangle.perimeter());
System.out.println(7/2);
	}

}
