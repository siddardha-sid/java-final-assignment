package PROBLEMS;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class problem10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> numbers = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements: ");
        int count = scanner.nextInt();

        System.out.println("Enter " + count + " integers:");
        for (int i = 0; i < count; i++) {
            int num = scanner.nextInt();
            numbers.add(num);
        }

        if (numbers.size() < 2) {
            System.out.println("Insufficient number of elements.");
            return;
        }

        Collections.sort(numbers);

        int secondSmallest = numbers.get(1);
        int secondLargest = numbers.get(numbers.size() - 2);

        System.out.println("Second smallest number: " + secondSmallest);
        System.out.println("Second largest number: " + secondLargest);
	}

}
