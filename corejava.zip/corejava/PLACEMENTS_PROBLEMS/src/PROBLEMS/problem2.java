package PROBLEMS;
class Animal{
	private String name;
	private int lifespan;
	private String sex;
	public Animal(String name, int lifespan, String sex) {
		super();
		this.name = name;
		this.lifespan = lifespan;
		this.sex = sex;
	}
	@Override
	public String toString() {
		return "Animal [name=" + name + ", lifespan=" + lifespan + ", sex=" + sex + "]";
	}
	
}
class Dog extends Animal{

	public Dog(String name, int lifespan, String sex) {
		super(name, lifespan, sex);
		
	}
	
}
//key points-super() method is used to call parent class constructor,and super() method should be used only
//used on first line of constructor.
public class problem2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Animal a=new Dog("max",13,"male");
System.out.println(a);
	}

}
