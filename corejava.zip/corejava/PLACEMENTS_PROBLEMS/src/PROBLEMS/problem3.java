package PROBLEMS;

import java.util.Scanner;
class NegativeNumberException extends Exception{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NegativeNumberException(String message) {
	        super(message);
	    }
}

public class problem3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	userInput();
} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	}
	public static void userInput() throws Exception {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter positive number");
		int num=scan.nextInt();
		if(num<0) {
			throw new NegativeNumberException("Negative numbers are not accepted");
		}
	}

}
