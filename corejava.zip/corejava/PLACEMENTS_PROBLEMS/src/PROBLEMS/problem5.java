package PROBLEMS;
interface Myinterface{
	final public static int var=10;//for variable it is fixed
	//complete abstraction possible with interface
	void completeAbstract();
}

abstract class MyAbstract{
	//abstract class cannot be instantiated,but still it can have constuctor because it can be initialized through child class
	//partial abstraction is possible with abstract keyword.
	int a;
	private String name;
	protected double d;
	public abstract void hide();
	public static void load() {
		System.out.println("i am loading");
	}
	public void run() {
		System.out.println("i am running");
	}
}

public class problem5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
