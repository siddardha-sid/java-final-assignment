package PROBLEMS;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Employee{
	private int id;
	private String name;
	private double salary;
	public Employee(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	
	
	
	
}
public class problem6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Employee> emp=new ArrayList<Employee>();
emp.add(new Employee(1,"siddu",23000));
emp.add(new Employee(2,"gow",27000));
emp.add(new Employee(3,"siddu",15000));
emp.add(new Employee(4,"madhav",27000));
emp.add(new Employee(5,"yadhav",90000));
List<Employee> filteredEmp=emp.stream().filter(e->e.getSalary()>25000).collect(Collectors.toList());
filteredEmp.forEach(e->System.out.println(e));
	}
	

}
