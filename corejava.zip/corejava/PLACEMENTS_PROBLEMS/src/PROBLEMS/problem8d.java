package PROBLEMS;
class Thread1 extends Thread{
	@Override
	public void run() {
		for(int i=1;i<=10;i++) {
			if(i%2==0) {
				System.out.println("first thread :"+i);
				
			}
		}
	}
}
class Thread2 extends Thread{
	@Override
	public void run() {
		for(int i=1;i<=10;i++) {
			if(i%2!=0) {
				System.out.println("second thread :"+i);
				
			}
		}
	}
}
public class problem8d {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Thread1 t1=new Thread1();
t1.start();
Thread2 t2=new Thread2();
t2.start();
	}

}
