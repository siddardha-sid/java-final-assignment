package ai.ineuron;

public class HdfcBank implements IBank {
	double balance,deposit,withdraw=0;
    @Override
	public double checkBalance() {
		if(balance<=0) {
			System.out.println("please deposit money into you account");
		}
		return balance;
	}
   @Override
	public double depositMoney(double deposit) {
		this.deposit=deposit;
		balance=balance+deposit;
		return deposit;
	}
   @Override
	public double withdrawMoney(double withdraw) {
	   if(balance<=0) {
		   System.out.println("you dont have enough money to withdraw");
		   return -1;
	   }else {
	   this.withdraw=withdraw;
	   balance=balance-withdraw;
	   
		return withdraw;
	   }
	}

}
