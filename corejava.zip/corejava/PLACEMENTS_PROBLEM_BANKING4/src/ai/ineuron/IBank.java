package ai.ineuron;

public interface IBank {
public double checkBalance();
public double depositMoney(double deposit);
public double withdrawMoney(double withdraw);

}
