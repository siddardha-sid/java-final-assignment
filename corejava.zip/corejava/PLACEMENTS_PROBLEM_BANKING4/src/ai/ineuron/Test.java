package ai.ineuron;

import java.util.Scanner;

public class Test {
static int number;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IBank ibank=new HdfcBank();
		Scanner scan=new Scanner(System.in);
	   
	   for(int i=0;i<=10;i++) {
		   System.out.println("please enter 1)deposit 2)withdrawl 3)balance 4)exit");
		   number=scan.nextInt();
	  if(number==4) {
		  scan.close();
		  break;
	  }else if(number==1) {
		  System.out.println("enter money to deposit");
		 double money= scan.nextDouble();
		System.out.println("deposited money"+ibank.depositMoney(money));
		
	  }else if(number==3) {
			System.out.println("your account balance is"+ibank.checkBalance()); ;
	  }
	  else if(number==2) {
		  System.out.println("enter money to withdrawl");
			 double money= scan.nextDouble();
			System.out.println(" money withdrawl "+ibank.withdrawMoney(money)); ;
	  }
	  
	   }
	   System.out.println("please come again we are happy to provide service 24/7");
	}

}
