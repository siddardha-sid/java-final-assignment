import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MyJDBC {
	static Connection con=null;
	static Statement statement=null;
	static ResultSet resultSet=null;

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		String url = "jdbc:mysql:///sys";
        String username = "root";
        String password = "Ronaldo@718";
        try {
        		con = DriverManager.getConnection(url, username, password);
            String query = "select * from students";
             statement = con.createStatement();
            ResultSet resultSet=statement.executeQuery(query);
            while (resultSet.next()) {
                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                int age = resultSet.getInt(3);

                System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
        	if(resultSet!=null) {
        		resultSet.close();
        	}if(statement!=null) {
        		statement.close();
        	}
        	if(con!=null) {
        		con.close();
        	}
        }
	}

}
