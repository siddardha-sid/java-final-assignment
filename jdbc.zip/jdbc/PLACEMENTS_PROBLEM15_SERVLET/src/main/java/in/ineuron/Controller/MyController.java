package in.ineuron.Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.model.Students;

/**
 * Servlet implementation class MyController
 */
public class MyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Connection con=null;
	static Statement statement=null;
	static ResultSet resultSet=null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("rquest came here");
		String url = "jdbc:mysql://localhost:3306/sys";
        String username = "root";
        String password = "Ronaldo@718";
        try {
        	 Class.forName("com.mysql.cj.jdbc.Driver");
        		con = DriverManager.getConnection(url, username, password);
            String query = "select * from students";
             statement = con.createStatement();
            ResultSet resultSet=statement.executeQuery(query);
            List<Students> st=new ArrayList<Students>();
            while (resultSet.next()) {
                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                int age = resultSet.getInt(3);
                st.add(new Students(id,name,age));
            }
            request.setAttribute("students", st);
            RequestDispatcher rd=request.getRequestDispatcher("students.jsp");
            rd.forward(request, response);
           
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
        	if(resultSet!=null) {
        		try {
					resultSet.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	}if(statement!=null) {
        		try {
					statement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	}
        	if(con!=null) {
        		try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	}
        }
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
