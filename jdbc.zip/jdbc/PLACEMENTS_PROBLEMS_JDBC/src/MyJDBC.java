import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MyJDBC {
	static Connection con=null;
	static Statement statement=null;
	static ResultSet resultSet=null;

	private static  String DB_URL = "jdbc:postgresql://localhost:5432/cricket";
    private static  String DB_USER = "root";
    private static String DB_PASSWORD = "Ronaldo@718";
    private static  String INPUT_FILE = "ipl.txt";
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
	        try {
	            Class.forName("org.postgresql.Driver");
	            System.out.println("loading of class");

	            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
	            connection.setAutoCommit(false);
	            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO ipl (team, trophies) VALUES (?, ?)");

	            BufferedReader reader = new BufferedReader(new FileReader(INPUT_FILE));
	            String line;
	            while ((line = reader.readLine()) != null) { 
	                String[] columns = line.split(",");
	                preparedStatement.setString(1, columns[0].trim());
	                preparedStatement.setString(2, columns[1].trim());
	                preparedStatement.addBatch();
	            }

	            int[] updateCounts = preparedStatement.executeBatch();

	            connection.commit();
	            System.out.println("Rows affected: " + updateCounts.length);

	            if(preparedStatement!=null || connection!=null) {
	            preparedStatement.close();
	            reader.close();
	            connection.close();
	            }
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}

}
