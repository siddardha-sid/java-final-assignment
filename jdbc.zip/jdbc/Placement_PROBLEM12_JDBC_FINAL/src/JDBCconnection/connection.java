package JDBCconnection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class connection {
private connection() {
	
}
static Connection con;
public static Connection getConnection() {
try {
	FileInputStream fis=new FileInputStream("appliation.properties");
	Properties p=new Properties();
	p.load(fis);
	con=DriverManager.getConnection(p.getProperty("url"), p.getProperty("uname"), p.getProperty("password"));
} catch (SQLException e) {
	e.printStackTrace();
}catch(FileNotFoundException e) {
	e.printStackTrace();
}catch(IOException e) {
	e.printStackTrace();
}
return con;
}
}
