package ineuron.DaoFactory;

import ineuron.persistence.IStudent;
import ineuron.persistence.StudentImpl;

public class PersistenceObject {
private PersistenceObject() {
	
}
static IStudent istudent;
public static IStudent getPersistenceObject() {
	istudent=new StudentImpl();
	return istudent;
}
}
