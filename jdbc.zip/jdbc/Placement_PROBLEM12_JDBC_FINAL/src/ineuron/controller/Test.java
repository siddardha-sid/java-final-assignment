package ineuron.controller;

import ineuron.StudentDTO.Student;
import ineuron.service.IStudentService;
import ineuron.serviceFactory.ServiceObject;

public class Test {
	static IStudentService iss=ServiceObject.getServiceObject();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//addStudent();
		//updateStudent();
		//deleteRecord();
		getStudentDetails();

	}
	public static void addStudent() {
		String status=iss.addStudent("prajna", 21,"aditya" );
		if(status.equalsIgnoreCase("success")) {
			System.out.println("record inserted successfully");
		}else System.out.println("record not inserted");
	}
	public static void updateStudent() {
		String status=iss.updateStudent(1);
		if(status.equalsIgnoreCase("success")) {
			System.out.println("record updated successfully");
		}else System.out.println("record not updated");
	}
	public static void deleteRecord() {
		String status=iss.deleteRecord(2);
		if(status.equalsIgnoreCase("success")) {
			System.out.println("record deleted successfully");
		}else System.out.println("record not deleted");
	}
	public static void getStudentDetails() {
		Student s=iss.getStudent(1);
		System.out.println(s.getSid()+" "+s.getSname()+" "+s.getSage()+" "+s.getScollege());
	}

}
