package ineuron.persistence;

import ineuron.StudentDTO.Student;

public interface IStudent {
public String addStudent(String sname,Integer sage,String scollege);

public String updateStudent(Integer sid);

public String deleteRecord(Integer sid);

public Student getStudent(Integer sid);
}
