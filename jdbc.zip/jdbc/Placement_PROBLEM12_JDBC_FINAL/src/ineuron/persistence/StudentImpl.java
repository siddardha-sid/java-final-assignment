package ineuron.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import JDBCconnection.connection;
import ineuron.StudentDTO.Student;

public class StudentImpl implements IStudent {
Connection con;
Statement st;
PreparedStatement pstmt;
ResultSet rs;
Student s;

	@Override
	public String addStudent(String sname, Integer sage, String scollege) {
		con=connection.getConnection();
		int rowsAffected=0;
		try {
			pstmt=con.prepareStatement("insert into students(sname,sage,scollege) values(?,?,?);");
			pstmt.setString(1, sname);
			pstmt.setInt(2, sage);
			pstmt.setString(3, scollege);
			if(pstmt!=null) {
				rowsAffected=pstmt.executeUpdate();
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(rowsAffected>0) {
			return "success";
		}else return "failure";
		
	}

	@Override
	public String updateStudent(Integer sid) {
		int rowsAffected=0;
		con=connection.getConnection();
		try {
			st=con.createStatement();
			rowsAffected=st.executeUpdate("update students set sname='siddu' where sid="+sid+";");
		} catch (SQLException e) {
			e.printStackTrace();
		}if(rowsAffected>0) {
			return "success";
		}else
		return "failure";
	}

	@Override
	public String deleteRecord(Integer sid) {
		int rowsAffected=0;
		con=connection.getConnection();
		try {
			st=con.createStatement();
			rowsAffected=st.executeUpdate("delete from students where sid="+sid+"");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(rowsAffected>0) {
			return "success";
		}else
		return "failure";
		
	}

	@Override
	public Student getStudent(Integer sid) {
		con=connection.getConnection();
		try {
			st=con.createStatement();
			rs=st.executeQuery("select sid,sname,sage,scollege from students where sid="+sid+";");
			if(rs.next()) {
				s=new Student();
				s.setSid(rs.getInt(1));
				s.setSname(rs.getString(2));
				s.setSage(rs.getInt(3));
				s.setScollege(rs.getString(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}

}
