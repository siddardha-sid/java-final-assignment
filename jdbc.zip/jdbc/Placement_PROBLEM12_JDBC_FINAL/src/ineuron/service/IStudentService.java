package ineuron.service;

import ineuron.StudentDTO.Student;

public interface IStudentService {
	public String addStudent(String sname,Integer sage,String scollege);

	public String updateStudent(Integer sid);

	public String deleteRecord(Integer sid);

	public Student getStudent(Integer sid);
}
