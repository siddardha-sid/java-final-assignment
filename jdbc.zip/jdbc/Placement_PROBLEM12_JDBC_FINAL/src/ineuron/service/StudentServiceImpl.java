package ineuron.service;

import ineuron.DaoFactory.PersistenceObject;
import ineuron.StudentDTO.Student;
import ineuron.persistence.IStudent;

public class StudentServiceImpl implements IStudentService {
IStudent is;
	@Override
	public String addStudent(String sname, Integer sage, String scollege) {
		 is=PersistenceObject.getPersistenceObject();
		 String status=is.addStudent(sname, sage, scollege);
		return status;
	}

	@Override
	public String updateStudent(Integer sid) {
		is=PersistenceObject.getPersistenceObject();
		String status=is.updateStudent(sid);
		return status;
	}

	@Override
	public String deleteRecord(Integer sid) {
		is=PersistenceObject.getPersistenceObject();
		String status=is.deleteRecord(sid);
		return status;
	}

	@Override
	public Student getStudent(Integer sid) {
		is=PersistenceObject.getPersistenceObject();
		Student s=is.getStudent(sid);
		return s;
	}

}
