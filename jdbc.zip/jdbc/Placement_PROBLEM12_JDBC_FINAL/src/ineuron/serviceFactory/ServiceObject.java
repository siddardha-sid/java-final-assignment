package ineuron.serviceFactory;

import ineuron.service.IStudentService;
import ineuron.service.StudentServiceImpl;

public class ServiceObject {
private ServiceObject() {
	
}
static IStudentService istudentService;
public static  IStudentService getServiceObject() {
	istudentService=new StudentServiceImpl();
	return istudentService;
}
}
