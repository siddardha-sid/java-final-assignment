package in.ineuron.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.dao.BlodPostdaoImpl;
import in.ineuron.model.Blog;


@WebServlet("/vlogs")
public class WebBlogs extends HttpServlet {
	BlodPostdaoImpl dao=new BlodPostdaoImpl();
	private static final long serialVersionUID = 1L;	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String title = request.getParameter("title");
        String description = request.getParameter("description");
        String content = request.getParameter("content");

        Blog blogPost = new Blog();
        blogPost.setTitle(title);
        blogPost.setDescription(description);
        blogPost.setContent(content);

       dao.saveBlog(blogPost);

        response.sendRedirect(request.getContextPath() + "/list");
		
	}

}
