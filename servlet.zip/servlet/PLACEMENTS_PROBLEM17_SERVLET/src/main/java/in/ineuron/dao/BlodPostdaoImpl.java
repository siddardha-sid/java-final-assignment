package in.ineuron.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import in.ineuron.model.Blog;

public class BlodPostdaoImpl implements IBlogPostdao {

	
	private final String jdbcUrl = "jdbc:mysql://localhost:3306/clientblogs";
    private final String username = "root";
    private final String password = "Ronaldo@718";
	
	@Override
	public void saveBlog(Blog b) {
		try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
	            PreparedStatement statement = connection.prepareStatement(
	                "INSERT INTO posts (title, description, content, created_at) VALUES (?, ?, ?, ?)")) {

	            statement.setString(1, b.getTitle());
	            statement.setString(2, b.getDescription());
	            statement.setString(3, b.getContent());
	            statement.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
	            statement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	}

	@Override
	public List<Blog> getBlogs() {
		List<Blog> blogPosts = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM posts ORDER BY created_at DESC")) {

            while (resultSet.next()) {
                Blog blogPost = new Blog();
                blogPost.setId(resultSet.getInt("id"));
                blogPost.setTitle(resultSet.getString("title"));
                blogPost.setDescription(resultSet.getString("description"));
                blogPost.setContent(resultSet.getString("content"));
                blogPost.setCreatedAt(resultSet.getTimestamp("created_at"));
                blogPosts.add(blogPost);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return blogPosts;
	}

}
