package in.ineuron.dao;

import java.util.List;

import in.ineuron.model.Blog;

public interface IBlogPostdao {

	public void saveBlog(Blog b);
	public List<Blog> getBlogs();
}
