package in.ineuron.model;

import java.sql.Timestamp;

public class Blog {

	private int id;
    private String title;
    private String description;
    private String content;
    private Timestamp createdAt;
    
   
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Timestamp getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}
	@Override
	public String toString() {
		return "Blog [id=" + id + ", title=" + title + ", description=" + description + ", content=" + content
				+ ", createdAt=" + createdAt + "]";
	}
	
    
    
}
