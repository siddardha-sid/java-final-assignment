package in.ineuron.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import in.ineuron.dto.Student;


@WebServlet("/test")
public class MyController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("username");
		Integer age=Integer.parseInt(request.getParameter("userage"));
		String college=request.getParameter("usercollege");
		HttpSession session=request.getSession(false);
		  List<Student> li=new ArrayList<Student>();
		 
		  li.add(new Student(name,age,college));
		  System.out.println(li);
		  
		  session.setAttribute("info", li);
		  
		  RequestDispatcher ds=request.getRequestDispatcher("student.jsp");
		  ds.forward(request, response);
	}

}
