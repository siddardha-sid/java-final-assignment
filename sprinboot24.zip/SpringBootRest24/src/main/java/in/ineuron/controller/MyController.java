package in.ineuron.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.model.Employee;
import in.ineuron.service.StudentServiceImpl;

@RestController
public class MyController {

	@Autowired
	private StudentServiceImpl empservice;
	
	@PostMapping("api/save")
	public ResponseEntity<String> serviceProvider(@RequestBody Employee e) {
		String status=empservice.sendData(e);
		System.out.println(status);
		return new ResponseEntity<String>(status,HttpStatus.OK);
	}
}
