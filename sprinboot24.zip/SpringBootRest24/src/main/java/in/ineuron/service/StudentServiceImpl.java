package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.dao.UserRepository;
import in.ineuron.model.Employee;


@Service
public class StudentServiceImpl implements IEmployeeService {
    @Autowired
	private UserRepository repo;
	
	@Override
	public String sendData(Employee e) {
		Employee emp=repo.save(e);
		if(emp!=null) {
			return "data is stored into database";
		}
		return "data not stored into database";
	}

}
