package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import in.ineuron.service.MyService;
@SpringBootApplication
public class SpringBoot25aopApplication {

	public static void main(String[] args) {
		ApplicationContext appcon=SpringApplication.run(SpringBoot25aopApplication.class, args);
		MyService service=appcon.getBean(MyService.class);
		service.performOperation1("siddu");
		service.performOperation2(10);
	}

}
