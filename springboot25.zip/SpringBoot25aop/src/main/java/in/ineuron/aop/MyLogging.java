package in.ineuron.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class MyLogging {

	@Before("execution(* in.ineuron.service.*.*(..))")
    public void logMethodCall(JoinPoint joinPoint) {
        System.out.println("Method called: " + joinPoint.getSignature().getName());
        Object[] args = joinPoint.getArgs();
        for (Object arg : args) {
            System.out.println("Input parameter: " + arg);
        }
    }

    @AfterReturning(pointcut = "execution(* in.ineuron.service.*.*(..))", returning = "result")
    public void logMethodReturn(JoinPoint joinPoint, Object result) {
        System.out.println("Method returned: " + joinPoint.getSignature().getName());
        System.out.println("Output parameter: " + result);
    }

}
