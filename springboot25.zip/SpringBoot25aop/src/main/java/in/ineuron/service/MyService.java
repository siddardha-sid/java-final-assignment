package in.ineuron.service;

import org.springframework.stereotype.Service;

@Service
public class MyService {

	public void performOperation1(String input) {
        System.out.println("Performing Operation 1 with input: " + input);
        // Perform operation logic here
    }

    public int performOperation2(int input) {
        System.out.println("Performing Operation 2 with input: " + input);
        // Perform operation logic here
        int result = input * 2;
        System.out.println("Operation 2 Result: " + result);
        return result;
    }
}
