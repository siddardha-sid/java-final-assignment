package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot26Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot26Application.class, args);
	}

}
