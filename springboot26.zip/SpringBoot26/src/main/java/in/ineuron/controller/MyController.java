package in.ineuron.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.dao.MyProductDetails;
import in.ineuron.model.Product;

@RestController
public class MyController {
private MyProductDetails prod;
	@GetMapping
	   public List<Product> getAllProducts() {
	      return prod.findAll();
	   }

	   @GetMapping("/{id}")
	   public Optional<Product> getProductById(@PathVariable Integer id) {
	      return prod.findById(id);
	   }

	   @PostMapping
	   public Product createProduct(@RequestBody Product product) {
	      return prod.save(product);
	   }

	   @PutMapping("/{id}")
	   public Product updateProduct(@PathVariable Integer id, @RequestBody Product updatedProduct) {
	      Product product = prod.findById(id).orElse(null);
	      if (product != null) {
	         product.setName(updatedProduct.getName());
	         product.setDescription(updatedProduct.getDescription());
	         // Update any other fields as needed
	         return prod.save(product);
	      }
	      return null;
	   }
	   @DeleteMapping("/{id}")
	   public void deleteProduct(@PathVariable Integer id) {
		   prod.deleteById(id);
	   }
}
