package in.ineuron.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Sort;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.model.Product;
import in.ineuron.service.StudentServiceImpl;

@RestController
public class MyController {

	@Autowired
	private StudentServiceImpl empservice;
	
	@PostMapping("api/save")
	public ResponseEntity<String> serviceProvider(@RequestBody Product e) {
		String status=empservice.sendData(e);
		System.out.println(status);
		return new ResponseEntity<String>(status,HttpStatus.OK);
	}
	@GetMapping(("api/get"))
    public List<Product> getUsers(@RequestParam(required = false) String name,
                               @RequestParam(required = false) Integer age,
                               @RequestParam(defaultValue = "0") int page,
                               @RequestParam(defaultValue = "10") int size,
                               @RequestParam(defaultValue = "id,asc") String sort) {
        // Create a Pageable object for pagination and sorting
        Pageable pageable = PageRequest.of(page, size, Sort.by(parseSortExpression(sort)));

        // Use the UserRepository to retrieve users with filtering, sorting, and paging
        if (name != null && age != null) {
            return empservice.findByNameAndAge(name, age, pageable);
        } else if (name != null) {
            return empservice.findByName(name, pageable);
        } else if (age != null) {
            return empservice.findByAge(age, pageable);
        } else {
            return empservice.findAll(pageable).getContent();
        }
    }
}
