package in.ineuron.service;

import in.ineuron.model.Product;

public interface IProductService {

	public String sendData(Product e);
}
