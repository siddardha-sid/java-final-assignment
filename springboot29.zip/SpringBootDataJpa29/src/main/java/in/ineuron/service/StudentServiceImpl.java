package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.dao.UserRepository;
import in.ineuron.model.Product;


@Service
public class StudentServiceImpl implements IProductService {
    @Autowired
	private UserRepository repo;
	
	@Override
	public String sendData(Product e) {
		Product p=repo.save(e);
		if(p!=null) {
			return "data is stored into database";
		}
		return "data not stored into database";
	}

}
