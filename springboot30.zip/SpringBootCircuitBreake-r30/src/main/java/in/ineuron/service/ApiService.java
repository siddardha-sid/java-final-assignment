package in.ineuron.service;

import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ApiService {
	
	private final CircuitBreakerFactory circuitBreakerFactory;
    private final RestTemplate restTemplate;

    public ApiService(CircuitBreakerFactory circuitBreakerFactory, RestTemplate restTemplate) {
        this.circuitBreakerFactory = circuitBreakerFactory;
        this.restTemplate = restTemplate;
    }

    public String getApiResponse() {
        return circuitBreakerFactory.create("api-circuit-breaker")
                .run(() -> restTemplate.getForObject("https://api.example.com/endpoint", String.class),
                        throwable -> handleApiFailure());
    }

    private String handleApiFailure() {
        return "Fallback response";
    }

}
